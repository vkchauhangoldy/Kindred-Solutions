import React from 'react'
import { Link } from 'react-router-dom';
import classes from '../Signin/Signin.module.css'
const Forgot = () => {
    return (
        <div className={classes.container} >
            <form className={classes.form}>
                <h1>Forgot Password</h1>
                <p>To reset your account password, enter the email address you registered with, and we will email you the instructions to reset the password.</p>
                <div className={classes['input-controls']}>
                    <label>Email</label>
                    <input type="email" placeholder='Email' />
                </div>

                <div className={classes['action-controls']}>
                    <button>Send Instructions</button>
                </div>
                <div className={classes.forgot}>
                    <p><Link to='/' className={classes.link}>Return to Signin Page</Link></p>
                </div>
            </form>
        </div>
    )
}

export default Forgot
