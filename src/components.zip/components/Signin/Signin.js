import React from 'react'

import { Link } from 'react-router-dom';
import classes from './Signin.module.css';
import Aside from '../Aside/Aside';

const Signin = () => {
    return (
        <div className={classes.wrapper}>
            <div><Aside /></div>
            <div className={classes.container} >
                <form className={classes.form}>
                    <h1>Login</h1>
                    <div className={classes['input-controls']}>
                        <label>Email</label>
                        <input type="email" placeholder='Email' />
                    </div>
                    <div className={classes['input-controls']}>
                        <label>Password</label>
                        <input type="password" placeholder='Password' />
                    </div>
                    <div className={classes['action-controls']}>
                        <button>Sign In</button>
                    </div>
                    <div className={classes.forgot}>
                        <p><Link to='/forgot' className={classes.link}>Forgot Password</Link></p>
                    </div>
                </form>
            </div>
        </div>
    )
}
export default Signin;